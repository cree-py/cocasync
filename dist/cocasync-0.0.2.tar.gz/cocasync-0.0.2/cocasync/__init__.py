from .client import *

__author__ = 'Umbresp'
__title__ = 'cocasync'
__license__ = 'MIT'
__version__ = '0.0.2'
__github__ = 'https://www.github.com/cree-py/cocasync'